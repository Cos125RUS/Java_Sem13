package org.example.self.calculator;

public interface Logger {
    void loggerOut(String message);
}
