package org.example.self.calculator;

public interface ICalculableFactory {
    Calculable create(int primaryArg);
}
