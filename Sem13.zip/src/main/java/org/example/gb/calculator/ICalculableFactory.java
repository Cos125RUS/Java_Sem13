package org.example.gb.calculator;

public interface ICalculableFactory {
    Calculable create(int primaryArg);
}
